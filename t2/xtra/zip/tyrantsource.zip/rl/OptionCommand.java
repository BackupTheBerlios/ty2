package rl;

public class OptionCommand {
	public void select(char c) {
	
	}
}