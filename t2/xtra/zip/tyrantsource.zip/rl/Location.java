package rl;

class Location extends Object {
	
	
	
}