package rl;

public class DirectionCommand {
	public void select(int dx, int dy, boolean action) {
	}
}