package rl;

public class TargetCommand {
	public void select(Map m, int x, int y) {
	
	}
}