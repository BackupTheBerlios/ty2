//
// Interface for objects than can be talked to
//
package rl;

public interface Talkable {
  public void talk(Thing t); 
}