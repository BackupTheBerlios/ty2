package rl;

public class Vault extends Map {

  public Vault(int w, int h) {
    super(w,h); 
  }

  public String getLevelName() {
    return "A darkened vault";  
  }
}