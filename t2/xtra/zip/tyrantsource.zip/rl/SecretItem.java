package rl;

public class SecretItem extends Secret {
  
  public SecretItem(Thing it) {
    super(it); 
  }
}