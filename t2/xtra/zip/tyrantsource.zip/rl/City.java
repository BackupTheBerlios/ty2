// Map object for cities
// also includes useful static builder functions

package rl;

import java.awt.*;

public class City extends Map {

  public City(int w, int h) {
    super(w,h); 
  }
 
  public static void buildCitadel(Map m, int x1, int y1, int x2, int y2) {
    
    
  }

  public static void buildFortressGate(Map m, int x1, int y1, int x2, int y2, int w) {
    
    
  }


}