package rl;

public class ActiveAttribute extends Attribute implements Active {
	public void action(int time) {}
	
}