package rl;

interface InputHandler {
  void input(String s,int x,int y);
}

