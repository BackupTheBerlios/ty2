package rl;

public class SelectCommand {
	public void select(Object o) {
	}
}