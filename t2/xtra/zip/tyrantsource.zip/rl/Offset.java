package rl;

public final class Offset {
  public int x;
  public int y;
}